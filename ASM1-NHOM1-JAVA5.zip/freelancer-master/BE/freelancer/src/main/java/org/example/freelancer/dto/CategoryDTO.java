package org.example.freelancer.dto;

import lombok.Data;

@Data
public class CategoryDTO {
    private Integer id;
    private String categoryTitle;
}
